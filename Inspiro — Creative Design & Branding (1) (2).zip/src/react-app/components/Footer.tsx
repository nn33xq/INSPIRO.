import { Link } from 'react-router';
import { Mail, Phone, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/10 bg-neutral-950/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-6 md:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img 
                src="https://mocha-cdn.com/019946c0-989d-7266-831f-fc2a7f36b59f/image.png_5801.png" 
                alt="Inspiro Logo" 
                className="w-8 h-8 rounded-lg"
              />
              <span className="text-lg font-semibold text-white">Inspiro</span>
            </div>
            <p className="text-neutral-400 text-sm max-w-md mb-6">
              A creative design studio specializing in graphics, branding, and digital content creation. 
              Crafting professional, futuristic designs for clients worldwide.
            </p>
            <div className="flex items-center gap-4">
              <a 
                href="https://instagram.com/inspirostudio" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors duration-200"
              >
                <Instagram className="h-4 w-4 text-neutral-300" />
              </a>
              <a 
                href="https://linkedin.com/company/inspirostudio" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors duration-200"
              >
                <Linkedin className="h-4 w-4 text-neutral-300" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-medium mb-4">Quick Links</h3>
            <div className="space-y-2">
              <Link to="/" className="block text-sm text-neutral-400 hover:text-white transition-colors duration-200">
                Home
              </Link>
              <Link to="/about" className="block text-sm text-neutral-400 hover:text-white transition-colors duration-200">
                About Us
              </Link>
              <Link to="/services" className="block text-sm text-neutral-400 hover:text-white transition-colors duration-200">
                Services & Pricing
              </Link>
              <Link to="/order" className="block text-sm text-neutral-400 hover:text-white transition-colors duration-200">
                Place Order
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-medium mb-4">Contact</h3>
            <div className="space-y-3">
              <a 
                href="mailto:teaminspirostudio@gmail.com" 
                className="flex items-center gap-3 text-sm text-neutral-400 hover:text-white transition-colors duration-200"
              >
                <Mail className="h-4 w-4" />
                teaminspirostudio@gmail.com
              </a>
              <a 
                href="tel:+918276028293" 
                className="flex items-center gap-3 text-sm text-neutral-400 hover:text-white transition-colors duration-200"
              >
                <Phone className="h-4 w-4" />
                +91 8276028293
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/10 gap-4">
          <p className="text-sm text-neutral-400">
            © {currentYear} Inspiro. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="text-sm text-neutral-400 hover:text-white transition-colors duration-200">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-sm text-neutral-400 hover:text-white transition-colors duration-200">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useState } from 'react';
import { Link } from 'react-router';
import { Menu, X, Sparkles } from 'lucide-react';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Background blur overlay */}
      <div className="fixed top-0 left-0 right-0 z-40 h-20 bg-gradient-to-b from-neutral-950/90 via-neutral-950/80 to-transparent backdrop-blur-xl border-b border-white/5" />
      
      <header className="fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="flex items-center justify-between py-5">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="relative">
                <img 
                  src="https://mocha-cdn.com/019946c0-989d-7266-831f-fc2a7f36b59f/image.png_5801.png" 
                  alt="Inspiro Logo" 
                  className="w-9 h-9 rounded-lg group-hover:shadow-lg group-hover:shadow-purple-500/25 transition-all duration-300 group-hover:scale-105"
                />
                <div className="absolute -inset-1 bg-gradient-to-br from-purple-500 via-blue-500 to-teal-400 rounded-lg blur opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
              </div>
              <span className="text-lg font-semibold text-white tracking-tight bg-gradient-to-r from-white via-white to-neutral-300 bg-clip-text text-transparent">
                Inspiro
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link to="/" className="text-sm font-medium text-neutral-300 hover:text-white transition-colors duration-200">
                Home
              </Link>
              <Link to="/about" className="text-sm font-medium text-neutral-300 hover:text-white transition-colors duration-200">
                About Us
              </Link>
              <Link to="/services" className="text-sm font-medium text-neutral-300 hover:text-white transition-colors duration-200">
                Services
              </Link>
              <Link to="/contact" className="text-sm font-medium text-neutral-300 hover:text-white transition-colors duration-200">
                Contact
              </Link>
            </nav>

            {/* CTA Button */}
            <div className="hidden md:flex items-center gap-4">
              <Link 
                to="/order" 
                className="group relative inline-flex items-center gap-2 px-6 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 hover:border-white/20 text-sm font-medium text-white backdrop-blur-xl transition-all duration-300 hover:shadow-lg hover:shadow-white/5"
              >
                <span>Get Started</span>
                <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-teal-400 group-hover:scale-125 transition-transform duration-200" />
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors duration-200"
            >
              {isOpen ? <X className="h-5 w-5 text-white" /> : <Menu className="h-5 w-5 text-white" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <div className="md:hidden mt-2 pb-4">
              <div className="rounded-2xl bg-neutral-900/70 backdrop-blur-xl border border-white/10 p-4 space-y-2">
                <Link 
                  to="/" 
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-white/5 transition-colors duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  Home
                </Link>
                <Link 
                  to="/about" 
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-white/5 transition-colors duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  About Us
                </Link>
                <Link 
                  to="/services" 
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-white/5 transition-colors duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  Services
                </Link>
                <Link 
                  to="/contact" 
                  className="block rounded-lg px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-white/5 transition-colors duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  Contact
                </Link>
                <div className="pt-2 mt-2 border-t border-white/10">
                  <Link 
                    to="/order" 
                    className="flex items-center justify-center gap-2 rounded-xl bg-white/10 px-4 py-2.5 text-sm font-medium text-white border border-white/20 hover:bg-white/15 transition-colors duration-200"
                    onClick={() => setIsOpen(false)}
                  >
                    <span>Get Started</span>
                    <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-teal-400" />
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>
    </>
  );
}

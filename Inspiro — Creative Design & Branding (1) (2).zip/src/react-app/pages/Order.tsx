import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, CreditCard, Smartphone, Bitcoin, Check, AlertCircle } from 'lucide-react';

export default function OrderPage() {
  const [selectedService, setSelectedService] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    businessName: '',
    paymentMethod: '',
    projectDetails: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const services = [
    { id: 'poster', name: 'Poster/Flyer Design', price: '$23 - $76' },
    { id: 'banner', name: 'Banner/Web Header', price: '$15 - $68' },
    { id: 'logo', name: 'Logo Design', price: '$23 - $106', popular: true },
    { id: 'social', name: 'Social Media Post', price: '$5 - $13' },
    { id: 'business-card', name: 'Business Card Design', price: '$15 - $31' },
    { id: 'brochures', name: 'Brochures', price: '$38 - $136' },
    { id: 'company-profiles', name: 'Company Profiles', price: '$60 - $183' },
    { id: 'youtube-thumbnails', name: 'YouTube Thumbnails', price: '$5 - $13' },
    { id: 'portfolio-making', name: 'Portfolio Making', price: '$10 - $50' },
    { id: 'web-development', name: 'Web Development', price: '$100 - $600' },
    { id: 'custom-illustrations', name: 'Custom Illustrations', price: '$38 - $151' },
    { id: 'infographics', name: 'Infographics Design', price: '$23 - $68' },
    { id: 'ui-ux', name: 'UI/UX Design', price: '$68 - $242' },
    { id: 'starter-kit', name: 'Starter Brand Kit', price: '$76' },
    { id: 'launch-pack', name: 'Business Launch Pack', price: '$121' },
    { id: 'social-growth', name: 'Social Growth Pack', price: '$38' },
    { id: 'event-promo', name: 'Event Promo Pack', price: '$53' },
    { id: 'monthly-retainer', name: 'Monthly Social Retainer', price: '$136/month' }
  ];

  const paymentMethods = [
    { id: 'paypal', name: 'PayPal', icon: CreditCard, desc: 'International payments' },
    { id: 'upi', name: 'UPI', icon: Smartphone, desc: 'India only' },
    { id: 'gpay', name: 'Google Pay', icon: Smartphone, desc: 'India only' },
    { id: 'phonepe', name: 'PhonePe', icon: Smartphone, desc: 'India only' },
    { id: 'paytm', name: 'Paytm', icon: Smartphone, desc: 'India only' },
    { id: 'crypto', name: 'Cryptocurrency', icon: Bitcoin, desc: 'Global (optional)' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      
      // Create WhatsApp message
      const service = services.find(s => s.id === selectedService);
      const message = `Hi! I'm contacting you from Inspiro website. I am interested in ${service?.name || selectedService}. Here are my project details: ${formData.projectDetails}. My contact info: ${formData.fullName}, ${formData.email}, ${formData.phone}`;
      const whatsappUrl = `https://wa.me/918276028293?text=${encodeURIComponent(message)}`;
      
      // Open WhatsApp in new tab
      window.open(whatsappUrl, '_blank');
    }, 2000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (showSuccess) {
    return (
      <div className="relative overflow-hidden min-h-screen flex items-center justify-center">
        <div className="fixed inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950" />
        </div>

        <div className="relative z-10 max-w-md mx-auto px-6 text-center">
          <div className="p-8 rounded-3xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 backdrop-blur-xl border border-emerald-500/30">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
              <Check className="w-8 h-8 text-white" />
            </div>
            
            <h2 className="text-2xl font-semibold text-white mb-4">Order Submitted Successfully!</h2>
            <p className="text-neutral-300 mb-6">
              Your order has been received and you'll be redirected to WhatsApp to continue the conversation. 
              We'll contact you within 24 hours to discuss your project details.
            </p>
            
            <div className="space-y-3">
              <Link 
                to="/services" 
                className="block w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-teal-500 text-white font-medium text-center transition-all duration-200"
              >
                Order Another Service
              </Link>
              <Link 
                to="/" 
                className="block w-full py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium text-center transition-all duration-200"
              >
                Back to Home
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <main className="relative z-10">
        {/* Header */}
        <section className="pt-32 pb-12 px-6 md:px-8">
          <div className="max-w-4xl mx-auto">
            <Link 
              to="/services" 
              className="inline-flex items-center gap-2 text-neutral-400 hover:text-white transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Services
            </Link>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-light text-white mb-4 tracking-tight">
              Place Your{' '}
              <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-teal-400 bg-clip-text text-transparent">
                Order
              </span>
            </h1>
            <p className="text-lg text-neutral-400 mb-8">
              Fill out the form below and we'll get back to you within 24 hours to discuss your project.
            </p>

            {/* Important Notice */}
            <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/30 mb-8">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-white font-medium mb-1">Order Process</h3>
                  <p className="text-neutral-300 text-sm">
                    Complete the form below to submit your order. After submission, you'll be redirected to WhatsApp 
                    where we can discuss project details and arrange payment. No upfront payment required!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Order Form */}
        <section className="pb-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Service Selection */}
              <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10">
                <h2 className="text-2xl font-semibold text-white mb-6">Select Service</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {services.map((service) => (
                    <label 
                      key={service.id} 
                      className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                        selectedService === service.id 
                          ? 'border-purple-500 bg-purple-500/10' 
                          : 'border-white/10 bg-white/5 hover:border-white/20'
                      }`}
                    >
                      <input
                        type="radio"
                        name="service"
                        value={service.id}
                        checked={selectedService === service.id}
                        onChange={(e) => setSelectedService(e.target.value)}
                        className="sr-only"
                        required
                      />
                      
                      {service.popular && (
                        <div className="absolute -top-2 -right-2">
                          <span className="px-2 py-1 text-xs font-medium bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full">
                            Popular
                          </span>
                        </div>
                      )}
                      
                      <div className="text-white font-medium mb-1">{service.name}</div>
                      <div className="text-purple-400 font-semibold">{service.price}</div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Contact Information */}
              <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10">
                <h2 className="text-2xl font-semibold text-white mb-6">Contact Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-neutral-400 transition-colors duration-200"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-neutral-400 transition-colors duration-200"
                      placeholder="your@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-neutral-400 transition-colors duration-200"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-2">
                      Business Name
                    </label>
                    <input
                      type="text"
                      name="businessName"
                      value={formData.businessName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-neutral-400 transition-colors duration-200"
                      placeholder="Your business name (optional)"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10">
                <h2 className="text-2xl font-semibold text-white mb-2">Preferred Payment Method</h2>
                <p className="text-neutral-400 text-sm mb-6">Payment will be processed after project details are confirmed.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {paymentMethods.map((method) => (
                    <label 
                      key={method.id} 
                      className={`p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                        formData.paymentMethod === method.id 
                          ? 'border-purple-500 bg-purple-500/10' 
                          : 'border-white/10 bg-white/5 hover:border-white/20'
                      }`}
                    >
                      <input
                        type="radio"
                        name="paymentMethod"
                        value={method.id}
                        checked={formData.paymentMethod === method.id}
                        onChange={handleInputChange}
                        className="sr-only"
                        required
                      />
                      
                      <div className="flex items-center gap-3 mb-2">
                        <method.icon className="w-5 h-5 text-neutral-300" />
                        <span className="text-white font-medium">{method.name}</span>
                      </div>
                      <p className="text-neutral-400 text-sm">{method.desc}</p>
                    </label>
                  ))}
                </div>
              </div>

              {/* Project Details */}
              <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10">
                <h2 className="text-2xl font-semibold text-white mb-2">Project Details</h2>
                <p className="text-neutral-400 text-sm mb-6">
                  Please provide as much detail as possible about your project, including style preferences, colors, 
                  text content, and any reference materials or inspiration.
                </p>
                
                <textarea
                  name="projectDetails"
                  value={formData.projectDetails}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-white placeholder-neutral-400 transition-colors duration-200 resize-none"
                  placeholder="Describe your project requirements, style preferences, colors, text content, target audience, and any specific ideas you have in mind..."
                />
              </div>

              {/* Submit Button */}
              <div className="text-center">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-12 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      Submitting Order...
                    </span>
                  ) : (
                    'Submit Order & Continue to WhatsApp'
                  )}
                </button>
                
                <p className="text-neutral-400 text-sm mt-4">
                  By submitting this form, you agree to our terms of service and privacy policy.
                </p>
              </div>
            </form>
          </div>
        </section>
      </main>
    </div>
  );
}

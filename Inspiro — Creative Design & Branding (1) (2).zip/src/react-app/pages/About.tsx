import { Link } from 'react-router';
import { ArrowRight, Users, Award, Globe, Heart } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 mb-8">
              <Users className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-neutral-200">Meet the Creative Team</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-light text-white mb-6 tracking-tight leading-[0.95]">
              The Minds Behind{' '}
              <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-teal-400 bg-clip-text text-transparent">
                InspiroStudio
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto mb-12">
              Founded on the principles of creativity, professionalism, and global reach, 
              InspiroStudio brings exceptional design solutions to businesses worldwide.
            </p>
          </div>
        </section>

        {/* Founders Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Sammrit Ghosh */}
              <div className="relative group">
                <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105">
                  <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-purple-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <div className="relative">
                    <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 p-[2px]">
                      <div className="w-full h-full rounded-full bg-neutral-900 flex items-center justify-center">
                        <span className="text-2xl font-bold text-white">SG</span>
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-semibold text-white text-center mb-2">
                      Sammrit Ghosh
                    </h3>
                    <p className="text-purple-400 text-center mb-6">Co-Founder & Creative Director</p>
                    
                    <p className="text-neutral-300 text-center mb-6">
                      Leading the creative vision with a passion for innovative design and brand storytelling. 
                      Sammrit brings years of experience in graphic design and brand development to every project.
                    </p>
                    
                    <div className="flex flex-wrap justify-center gap-2">
                      {['Brand Design', 'Creative Direction', 'Visual Identity'].map((skill) => (
                        <span key={skill} className="px-3 py-1 text-xs rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Aditya Ghosh */}
              <div className="relative group">
                <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105">
                  <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-teal-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <div className="relative">
                    <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-teal-500 to-blue-500 p-[2px]">
                      <div className="w-full h-full rounded-full bg-neutral-900 flex items-center justify-center">
                        <span className="text-2xl font-bold text-white">AG</span>
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-semibold text-white text-center mb-2">
                      Aditya Ghosh
                    </h3>
                    <p className="text-teal-400 text-center mb-6">Co-Founder & Operations Director</p>
                    
                    <p className="text-neutral-300 text-center mb-6">
                      Ensuring seamless project delivery and client satisfaction. Aditya manages operations, 
                      client relationships, and quality control to deliver exceptional results on time.
                    </p>
                    
                    <div className="flex flex-wrap justify-center gap-2">
                      {['Project Management', 'Client Relations', 'Quality Assurance'].map((skill) => (
                        <span key={skill} className="px-3 py-1 text-xs rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Studio Story */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white mb-8 tracking-tight">
              Our Studio Story
            </h2>
            
            <div className="prose prose-lg prose-invert mx-auto">
              <p className="text-neutral-300 text-lg leading-relaxed mb-8">
                InspiroStudio was born from a shared vision to bridge the gap between creative excellence and 
                business success. What started as a passion project between two friends has evolved into a 
                trusted design partner for businesses worldwide.
              </p>
              
              <p className="text-neutral-300 text-lg leading-relaxed mb-8">
                We believe that great design isn't just about aesthetics—it's about creating meaningful 
                connections between brands and their audiences. Every project we undertake is an opportunity 
                to tell a unique story and drive real business results.
              </p>
              
              <p className="text-neutral-300 text-lg leading-relaxed">
                Today, InspiroStudio serves clients across the globe, delivering professional design solutions 
                that combine creativity with strategic thinking. We're not just designers—we're your creative partners 
                in building memorable brand experiences.
              </p>
            </div>
          </div>
        </section>

        {/* Core Values */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white text-center mb-16 tracking-tight">
              What Makes Us{' '}
              <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                Unique
              </span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: Heart,
                  title: 'Creativity',
                  description: 'We infuse every project with innovative thinking and artistic excellence, ensuring your brand stands out in a crowded marketplace.',
                  gradient: 'from-red-500 to-pink-500'
                },
                {
                  icon: Award,
                  title: 'Professionalism',
                  description: 'Our commitment to quality, timely delivery, and clear communication has earned us the trust of clients worldwide.',
                  gradient: 'from-blue-500 to-purple-500'
                },
                {
                  icon: Globe,
                  title: 'Global Reach',
                  description: 'Serving clients across continents, we understand diverse markets and cultural nuances in design and branding.',
                  gradient: 'from-teal-500 to-green-500'
                }
              ].map((value, idx) => (
                <div key={idx} className="group relative">
                  <div className="p-8 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105">
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity duration-300" 
                         style={{backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))`}} />
                    
                    <div className="relative">
                      <div className={`w-14 h-14 mb-6 rounded-xl bg-gradient-to-br ${value.gradient} p-[2px]`}>
                        <div className="w-full h-full rounded-xl bg-neutral-900 flex items-center justify-center">
                          <value.icon className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      
                      <h3 className="text-xl font-semibold text-white mb-4">{value.title}</h3>
                      <p className="text-neutral-300 leading-relaxed">{value.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { number: '500+', label: 'Projects Completed' },
                { number: '200+', label: 'Happy Clients' },
                { number: '50+', label: 'Countries Served' },
                { number: '2-3', label: 'Days Delivery' }
              ].map((stat, idx) => (
                <div key={idx} className="group">
                  <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 group-hover:scale-105">
                    <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent mb-2">
                      {stat.number}
                    </div>
                    <div className="text-neutral-300 text-sm font-medium">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="relative p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
              <h2 className="text-3xl md:text-4xl font-light text-white mb-4 tracking-tight">
                Ready to Work Together?
              </h2>
              <p className="text-lg text-neutral-400 mb-8">
                Let's bring your creative vision to life with professional design solutions.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link 
                  to="/services" 
                  className="px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
                >
                  View Our Services
                </Link>
                <Link 
                  to="/contact" 
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
                >
                  <span>Contact Us</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

import { useState } from 'react';
import { Link } from 'react-router';
import { Check, Star, Download, Zap, Users, Calendar, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';

export default function ServicesPage() {
  const [showMoreServices, setShowMoreServices] = useState(false);

  // First 8 core services
  const coreServices = [
    {
      title: 'Poster/Flyer Design',
      price: '$23 - $76',
      description: 'Eye-catching print and digital posters for events, promotions, and marketing campaigns.',
      features: ['Print-ready files', 'Multiple size options', 'Custom graphics', '2 revisions included']
    },
    {
      title: 'Banner/Web Header',
      price: '$15 - $68',
      description: 'Professional web banners and headers optimized for digital platforms and social media.',
      features: ['Web-optimized sizes', 'Social media formats', 'Brand consistent', 'Fast delivery']
    },
    {
      title: 'Logo Design',
      price: '$23 - $106',
      description: 'Custom logo design with multiple concepts and revisions to perfectly represent your brand.',
      features: ['2-3 logo concepts', 'Multiple revisions', 'Vector files (AI/EPS)', 'Various file formats'],
      popular: true
    },
    {
      title: 'Social Media Post',
      price: '$5 - $13',
      description: 'Engaging social media graphics designed for maximum impact and engagement.',
      features: ['Platform optimized', 'Brand consistent', 'Quick turnaround', 'Multiple formats']
    },
    {
      title: 'Business Card Design',
      price: '$15 - $31',
      description: 'Professional business card designs that make lasting first impressions.',
      features: ['Print-ready design', 'Double-sided options', 'Multiple concepts', 'Business card standards']
    },
    {
      title: 'Brochures',
      price: '$38 - $136',
      description: 'Multi-page brochures and marketing materials for comprehensive brand presentation.',
      features: ['Multi-page layouts', 'Print-ready files', 'Custom design', 'Professional formatting']
    },
    {
      title: 'Company Profiles',
      price: '$60 - $183',
      description: 'Professional company profile documents showcasing your business strengths and services.',
      features: ['10+ page layouts', 'Professional formatting', 'Custom graphics', 'Corporate design']
    },
    {
      title: 'YouTube Thumbnails',
      price: '$5 - $13',
      description: 'Click-worthy YouTube thumbnails designed to increase views and engagement.',
      features: ['YouTube optimized', 'Eye-catching design', 'Text overlay options', 'A/B testing variants']
    }
  ];

  // Additional services for "View More" section
  const additionalServices = [
    {
      title: 'Portfolio Making',
      price: '$10 - $50',
      description: 'Professional portfolio design for creatives and professionals.',
      features: ['Custom layouts', 'Print & digital ready', 'Multiple formats', 'Professional presentation']
    },
    {
      title: 'Web Development',
      price: '$100 - $600',
      description: 'Complete website development and programming solutions for businesses.',
      features: ['Responsive design', 'Custom functionality', 'SEO optimized', 'Mobile friendly', 'Modern frameworks']
    },
    {
      title: 'Custom Illustrations',
      price: '$38 - $151',
      description: 'Original custom illustrations for brands and marketing materials.',
      features: ['Original artwork', 'Vector graphics', 'Multiple styles', 'Commercial license']
    },
    {
      title: 'Infographics Design',
      price: '$23 - $68',
      description: 'Data visualization and informational graphics that engage and inform.',
      features: ['Data visualization', 'Custom icons', 'Brand consistent', 'Print & web ready']
    },
    {
      title: 'Animated Social Media Ads',
      price: '$38 - $121',
      description: 'Eye-catching animated GIFs and MP4s for social media advertising.',
      features: ['GIF & MP4 formats', 'Platform optimized', 'Animated elements', 'Engaging content']
    },
    {
      title: 'Presentation Decks',
      price: '$53 - $151',
      description: 'Professional slide decks for business presentations and pitches.',
      features: ['Custom templates', 'Infographics included', 'Brand consistent', 'Multiple formats']
    },
    {
      title: 'E-book / Digital PDF Design',
      price: '$38 - $136',
      description: 'Professional e-book and digital document design.',
      features: ['Multi-page layouts', 'Interactive elements', 'Print & digital ready', 'Professional typography']
    },
    {
      title: 'Packaging & Label Design',
      price: '$53 - $151',
      description: 'Product packaging and label design for retail and e-commerce.',
      features: ['Print-ready designs', 'Die-cut templates', 'Brand consistent', 'Retail standards']
    },
    {
      title: 'T-shirt / Merchandise Design',
      price: '$31 - $91',
      description: 'Custom designs for apparel and promotional merchandise.',
      features: ['Vector graphics', 'Print-ready files', 'Multiple formats', 'Commercial use']
    },
    {
      title: 'Album / Cover Art',
      price: '$38 - $106',
      description: 'Professional cover art for music albums, podcasts, and digital content.',
      features: ['High-resolution artwork', 'Multiple formats', 'Platform specs', 'Artistic design']
    },
    {
      title: 'Mockup & 3D Visualization',
      price: '$60 - $183',
      description: 'Professional 3D mockups and product visualizations.',
      features: ['Photorealistic rendering', 'Multiple angles', 'High resolution', 'Commercial use']
    },
    {
      title: 'UI/UX Design',
      price: '$68 - $242',
      description: 'User interface and experience design for apps and websites.',
      features: ['User-centered design', 'Wireframes included', 'Interactive prototypes', 'Modern interfaces']
    },
    {
      title: 'Brand Guidelines',
      price: '$91 - $304',
      description: 'Comprehensive brand style guides and guidelines documentation.',
      features: ['Complete style guide', 'Logo usage rules', 'Color & typography', 'Brand applications']
    },
    {
      title: 'Advertising Campaign Kit',
      price: '$76 - $242',
      description: 'Complete advertising campaign materials for Google Ads, Facebook, and Instagram.',
      features: ['Multiple ad formats', 'A/B test variants', 'Platform optimized', 'Campaign consistent']
    }
  ];

  // Updated bundles with new pricing
  const starterBundles = [
    {
      title: 'Starter Brand Kit',
      price: '$76',
      originalPrice: '$95',
      description: 'Perfect for new businesses looking to establish their brand identity.',
      features: [
        '1 logo (1 concept, 1 revision)',
        'Custom color palette & typography',
        '2 social media post templates'
      ],
      popular: false
    },
    {
      title: 'Business Launch Pack',
      price: '$121',
      originalPrice: '$151',
      description: 'Complete branding solution for businesses ready to make their mark.',
      features: [
        '2 logo concepts + 2 revisions',
        'Business card + letterhead',
        '4 social posts + 1 banner'
      ],
      popular: true
    },
    {
      title: 'Social Growth Pack',
      price: '$38',
      originalPrice: '$47',
      description: 'Boost your social media presence with consistent, engaging content.',
      features: [
        '8 posts (1 platform)',
        '2 story templates',
        '1 revision round'
      ],
      popular: false
    },
    {
      title: 'Event Promo Pack',
      price: '$53',
      originalPrice: '$66',
      description: 'Everything you need to promote your event across all channels.',
      features: [
        '1 poster/flyer + 1 web banner',
        '4 social media posts',
        'Multiple size variations'
      ],
      popular: false
    }
  ];

  const premiumBundles = [
    {
      title: 'Premium Brand Identity Pack',
      price: '$199',
      originalPrice: '$249',
      description: 'Complete brand identity solution for established businesses.',
      features: [
        '3 logo concepts + 3 revisions',
        'Brand guidelines (colors, typography, rules)',
        'Business card + letterhead',
        '5 social media post templates'
      ],
      popular: true
    },
    {
      title: 'Corporate Pitch Deck Pack',
      price: '$151',
      originalPrice: '$189',
      description: 'Professional presentation materials for business pitches.',
      features: [
        'Custom 10–15 slide pitch deck',
        'Infographics & charts',
        'Cover design + template system',
        '1 revision round'
      ],
      popular: false
    },
    {
      title: 'E-commerce Booster Pack',
      price: '$183',
      originalPrice: '$229',
      description: 'Complete e-commerce design solution for online businesses.',
      features: [
        '10 product mockups',
        'Packaging + label design',
        'Website banner + ad kit',
        '5 social media ads'
      ],
      popular: false
    },
    {
      title: 'Full Website Launch Pack',
      price: '$272',
      originalPrice: '$340',
      description: 'Complete website design solution for new business launches.',
      features: [
        '1-page responsive website design',
        'Hero banner + animated header',
        'Brand color + typography system',
        '2 custom graphics/illustrations'
      ],
      popular: false
    },
    {
      title: 'Ultimate Business Growth Pack',
      price: '$499',
      originalPrice: '$624',
      description: 'The complete business branding and marketing solution.',
      features: [
        'Full brand kit (logos, cards, letterhead, guidelines)',
        'Company profile (10 pages)',
        '15 social posts + 3 story templates',
        'Website landing page design',
        'Priority delivery included'
      ],
      popular: true
    }
  ];

  const addOns = [
    { title: 'Extra Revisions', price: '$3 - $6', description: 'Additional design revisions beyond included amount' },
    { title: 'Source Files (AI/PSD)', price: '$5 - $15', description: 'Original design files for future editing' },
    { title: 'Priority Delivery (40-58 hrs)', price: '+32-50% surcharge', description: 'Rush delivery for urgent projects' },
    { title: 'Stock Image Licensing', price: '$9 - $38 extra', description: 'Premium stock images for commercial use' },
    { title: 'Custom Icon Set', price: '$15 - $53 extra', description: 'Custom icon design for brand consistency' },
    { title: 'Complex Photo Retouching', price: '$23 - $76 extra', description: 'Advanced photo editing and manipulation' }
  ];

  return (
    <div className="relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950" />
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 mb-8">
              <Star className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-neutral-200">Professional Design Services</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-light text-white mb-6 tracking-tight leading-[0.95]">
              Services &{' '}
              <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-teal-400 bg-clip-text text-transparent">
                Pricing
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto mb-12">
              Professional design services with transparent pricing. Updated rates with comprehensive service offerings. 
              Quality design delivered in 2-3 days.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
              <Link 
                to="/order" 
                className="px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
              >
                Start Your Project
              </Link>
              
              <button className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300">
                <Download className="w-4 h-4" />
                Download Price List
              </button>
            </div>

            {/* Key Features */}
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-neutral-300">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span>2-3 Days Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Multiple Revisions</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-400" />
                <span>Global Client Base</span>
              </div>
            </div>
          </div>
        </section>

        {/* Core Services (First 8) */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white text-center mb-16 tracking-tight">
              Core Services
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {coreServices.map((service, idx) => (
                <div 
                  key={idx} 
                  className={`relative p-6 rounded-2xl backdrop-blur-xl border transition-all duration-300 hover:scale-105 ${
                    service.popular 
                      ? 'bg-gradient-to-br from-purple-500/10 to-teal-500/10 border-purple-500/30' 
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  {service.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full">
                        Most Popular
                      </span>
                    </div>
                  )}
                  
                  <h3 className="text-lg font-semibold text-white mb-2">{service.title}</h3>
                  <div className="text-xl font-bold text-purple-400 mb-3">{service.price}</div>
                  <p className="text-neutral-300 text-sm mb-4 leading-relaxed">{service.description}</p>
                  
                  <ul className="space-y-1 mb-4">
                    {service.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                        <Check className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    to="/order" 
                    className="block w-full py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-center text-white text-sm font-medium transition-all duration-200"
                  >
                    Order Now
                  </Link>
                </div>
              ))}
            </div>

            {/* View More Button */}
            <div className="text-center mt-12">
              <button
                onClick={() => setShowMoreServices(!showMoreServices)}
                className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
              >
                <span>{showMoreServices ? 'View Less Services' : 'View More Services'}</span>
                {showMoreServices ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Additional Services (Expandable) */}
            {showMoreServices && (
              <div className="mt-16">
                <h3 className="text-2xl md:text-3xl font-light text-white text-center mb-12 tracking-tight">
                  Additional{' '}
                  <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                    Services
                  </span>
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {additionalServices.map((service, idx) => (
                    <div 
                      key={idx} 
                      className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105"
                    >
                      <h3 className="text-lg font-semibold text-white mb-2">{service.title}</h3>
                      <div className="text-xl font-bold text-purple-400 mb-3">{service.price}</div>
                      <p className="text-neutral-300 text-sm mb-4 leading-relaxed">{service.description}</p>
                      
                      <ul className="space-y-1 mb-4">
                        {service.features.map((feature, fIdx) => (
                          <li key={fIdx} className="flex items-center gap-2 text-xs text-neutral-300">
                            <Check className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      
                      <Link 
                        to="/order" 
                        className="block w-full py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-center text-white text-sm font-medium transition-all duration-200"
                      >
                        Order Now
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Starter Bundles */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white text-center mb-4 tracking-tight">
              Starter{' '}
              <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                Bundles
              </span>
            </h2>
            <p className="text-neutral-400 text-center mb-16 max-w-3xl mx-auto">
              Perfect packages for new businesses and growing brands.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {starterBundles.map((bundle, idx) => (
                <div 
                  key={idx} 
                  className={`relative p-8 rounded-3xl backdrop-blur-xl border transition-all duration-300 hover:scale-105 ${
                    bundle.popular 
                      ? 'bg-gradient-to-br from-purple-500/10 to-teal-500/10 border-purple-500/30' 
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  {bundle.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="px-4 py-1.5 text-sm font-medium bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full">
                        Best Value
                      </span>
                    </div>
                  )}
                  
                  <h3 className="text-2xl font-semibold text-white mb-4">{bundle.title}</h3>
                  
                  <div className="flex items-center gap-3 mb-4">
                    <div className="text-3xl font-bold text-purple-400">{bundle.price}</div>
                    <div className="text-lg text-neutral-500 line-through">{bundle.originalPrice}</div>
                    <div className="px-2 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-medium rounded-full">
                      SAVE
                    </div>
                  </div>
                  
                  <p className="text-neutral-300 mb-6 leading-relaxed">{bundle.description}</p>
                  
                  <ul className="space-y-3 mb-8">
                    {bundle.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-3 text-sm text-neutral-300">
                        <Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    to="/order" 
                    className={`block w-full py-3 rounded-xl text-center font-medium transition-all duration-200 ${
                      bundle.popular 
                        ? 'bg-gradient-to-r from-purple-500 to-teal-500 text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40' 
                        : 'bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-white'
                    }`}
                  >
                    Choose This Package
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Premium Bundles */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white text-center mb-4 tracking-tight">
              Premium{' '}
              <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                Packages
              </span>
            </h2>
            <p className="text-neutral-400 text-center mb-16 max-w-3xl mx-auto">
              Comprehensive solutions for established businesses and large projects.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {premiumBundles.map((bundle, idx) => (
                <div 
                  key={idx} 
                  className={`relative p-8 rounded-3xl backdrop-blur-xl border transition-all duration-300 hover:scale-105 ${
                    bundle.popular 
                      ? 'bg-gradient-to-br from-purple-500/10 to-teal-500/10 border-purple-500/30' 
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  {bundle.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="px-4 py-1.5 text-sm font-medium bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full">
                        Popular
                      </span>
                    </div>
                  )}
                  
                  <h3 className="text-xl font-semibold text-white mb-4">{bundle.title}</h3>
                  
                  <div className="flex items-center gap-3 mb-4">
                    <div className="text-2xl font-bold text-purple-400">{bundle.price}</div>
                    <div className="text-sm text-neutral-500 line-through">{bundle.originalPrice}</div>
                  </div>
                  
                  <p className="text-neutral-300 text-sm mb-6 leading-relaxed">{bundle.description}</p>
                  
                  <ul className="space-y-2 mb-6">
                    {bundle.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2 text-xs text-neutral-300">
                        <Check className="w-3 h-3 text-emerald-400 flex-shrink-0 mt-1" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    to="/order" 
                    className={`block w-full py-3 rounded-xl text-center text-sm font-medium transition-all duration-200 ${
                      bundle.popular 
                        ? 'bg-gradient-to-r from-purple-500 to-teal-500 text-white shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40' 
                        : 'bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-white'
                    }`}
                  >
                    Choose Package
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Monthly Retainer */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white mb-4 tracking-tight">
                Monthly Social{' '}
                <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                  Retainer
                </span>
              </h2>
              <p className="text-neutral-400 text-lg">
                Consistent social media presence with ongoing design support.
              </p>
            </div>

            <div className="relative p-8 rounded-3xl bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
              <div className="absolute top-4 right-4">
                <Calendar className="w-6 h-6 text-purple-400" />
              </div>
              
              <h3 className="text-2xl font-semibold text-white mb-2">Monthly Social Retainer</h3>
              <div className="text-3xl font-bold text-purple-400 mb-4">$136/month</div>
              
              <p className="text-neutral-300 mb-6">
                Perfect for businesses looking to maintain consistent, professional social media presence.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <ul className="space-y-3">
                  {[
                    '20 posts per month',
                    'Content calendar + scheduling support',
                    '1 revision per post'
                  ].map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-sm text-neutral-300">
                      <Check className="w-4 h-4 text-emerald-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <ul className="space-y-3">
                  {[
                    'Multiple platform optimization',
                    'Brand consistency guaranteed',
                    'Extra platforms +$5 each'
                  ].map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-sm text-neutral-300">
                      <Check className="w-4 h-4 text-emerald-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              
              <Link 
                to="/order" 
                className="block w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-teal-500 text-white font-medium text-center shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-200"
              >
                Subscribe Monthly
              </Link>
            </div>
          </div>
        </section>

        {/* Add-Ons */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white text-center mb-16 tracking-tight">
              Custom Add-Ons
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {addOns.map((addon, idx) => (
                <div 
                  key={idx}
                  className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-lg font-semibold text-white">{addon.title}</h3>
                    <span className="text-purple-400 font-semibold text-sm">{addon.price}</span>
                  </div>
                  <p className="text-neutral-300 text-sm">{addon.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="relative p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
              <h2 className="text-3xl md:text-4xl font-light text-white mb-4 tracking-tight">
                Ready to Get Started?
              </h2>
              <p className="text-lg text-neutral-400 mb-8">
                Choose your service and let's bring your vision to life. Professional results in 2-3 days.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link 
                  to="/order" 
                  className="px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
                >
                  Place Your Order
                </Link>
                <Link 
                  to="/contact" 
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
                >
                  <span>Have Questions?</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

import { Mail, Phone, MessageCircle, Instagram, Linkedin, MapPin, Clock, Send } from 'lucide-react';

export default function ContactPage() {
  const handleWhatsAppClick = () => {
    const message = "Hi! I am interested in your design services. Here are my project details: [Please describe your project requirements]";
    const whatsappUrl = `https://wa.me/918276028293?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950" />
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 mb-8">
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-neutral-200">Let's Start a Conversation</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-light text-white mb-6 tracking-tight leading-[0.95]">
              Get in{' '}
              <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-teal-400 bg-clip-text text-transparent">
                Touch
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto mb-12">
              Ready to transform your brand? Contact us through your preferred method and let's discuss 
              how we can bring your creative vision to life.
            </p>
          </div>
        </section>

        {/* Contact Methods */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Left: Contact Info */}
              <div>
                <h2 className="text-3xl md:text-4xl font-light text-white mb-8 tracking-tight">
                  Contact Information
                </h2>

                {/* Primary Contact Methods */}
                <div className="space-y-6 mb-12">
                  <div className="group p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 p-[2px]">
                        <div className="w-full h-full rounded-xl bg-neutral-900 flex items-center justify-center">
                          <MessageCircle className="w-5 h-5 text-white" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">WhatsApp (Recommended)</h3>
                        <p className="text-neutral-400 text-sm">Instant messaging & project discussion</p>
                      </div>
                    </div>
                    <button
                      onClick={handleWhatsAppClick}
                      className="w-full py-3 px-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl text-white font-medium hover:shadow-lg hover:shadow-green-500/25 transition-all duration-200"
                    >
                      Start WhatsApp Chat
                    </button>
                  </div>

                  <div className="group p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 p-[2px]">
                        <div className="w-full h-full rounded-xl bg-neutral-900 flex items-center justify-center">
                          <Mail className="w-5 h-5 text-white" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">Email</h3>
                        <p className="text-neutral-400 text-sm">Detailed project discussions</p>
                      </div>
                    </div>
                    <a
                      href="mailto:teaminspirostudio@gmail.com"
                      className="block w-full py-3 px-4 text-center bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 rounded-xl text-white font-medium transition-all duration-200"
                    >
                      teaminspirostudio@gmail.com
                    </a>
                  </div>

                  <div className="group p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 p-[2px]">
                        <div className="w-full h-full rounded-xl bg-neutral-900 flex items-center justify-center">
                          <Phone className="w-5 h-5 text-white" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">Phone</h3>
                        <p className="text-neutral-400 text-sm">Direct calls & voice consultation</p>
                      </div>
                    </div>
                    <a
                      href="tel:+918276028293"
                      className="block w-full py-3 px-4 text-center bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 rounded-xl text-white font-medium transition-all duration-200"
                    >
                      +91 8276028293
                    </a>
                  </div>
                </div>

                {/* Social Media */}
                <div>
                  <h3 className="text-xl font-semibold text-white mb-4">Follow Us</h3>
                  <div className="flex gap-4">
                    <a
                      href="https://instagram.com/inspirostudio"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group p-4 rounded-xl bg-white/5 border border-white/10 hover:border-pink-500/50 hover:bg-pink-500/10 transition-all duration-300"
                    >
                      <Instagram className="w-6 h-6 text-neutral-300 group-hover:text-pink-400 transition-colors duration-200" />
                    </a>
                    <a
                      href="https://linkedin.com/company/inspirostudio"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group p-4 rounded-xl bg-white/5 border border-white/10 hover:border-blue-500/50 hover:bg-blue-500/10 transition-all duration-300"
                    >
                      <Linkedin className="w-6 h-6 text-neutral-300 group-hover:text-blue-400 transition-colors duration-200" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Right: Additional Info */}
              <div>
                <h2 className="text-3xl md:text-4xl font-light text-white mb-8 tracking-tight">
                  Studio Details
                </h2>

                <div className="space-y-8">
                  {/* Working Hours */}
                  <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <Clock className="w-6 h-6 text-purple-400" />
                      <h3 className="text-lg font-semibold text-white">Working Hours</h3>
                    </div>
                    <div className="space-y-2 text-neutral-300">
                      <div className="flex justify-between">
                        <span>Monday - Friday</span>
                        <span>9:00 AM - 8:00 PM IST</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Saturday</span>
                        <span>10:00 AM - 6:00 PM IST</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Sunday</span>
                        <span>Closed</span>
                      </div>
                    </div>
                  </div>

                  {/* Location */}
                  <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <MapPin className="w-6 h-6 text-teal-400" />
                      <h3 className="text-lg font-semibold text-white">Location</h3>
                    </div>
                    <p className="text-neutral-300">
                      Based in India, serving clients worldwide.<br />
                      Remote design studio with global reach.
                    </p>
                  </div>

                  {/* Response Time */}
                  <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <Send className="w-6 h-6 text-blue-400" />
                      <h3 className="text-lg font-semibold text-white">Response Time</h3>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-400" />
                        <span className="text-neutral-300">WhatsApp: Within 1 hour</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-400" />
                        <span className="text-neutral-300">Email: Within 24 hours</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-purple-400" />
                        <span className="text-neutral-300">Project delivery: 2-3 days</span>
                      </div>
                    </div>
                  </div>

                  {/* FAQ Quick Links */}
                  <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
                    <h3 className="text-lg font-semibold text-white mb-4">Frequently Asked Questions</h3>
                    <div className="space-y-3 text-sm">
                      <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                        <p className="text-white font-medium mb-1">What file formats do you provide?</p>
                        <p className="text-neutral-400">High-resolution PNG, JPG, PDF, and vector files (AI/EPS) when applicable.</p>
                      </div>
                      <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                        <p className="text-white font-medium mb-1">How many revisions are included?</p>
                        <p className="text-neutral-400">Most services include 2-3 revisions. Additional revisions available for $2-5.</p>
                      </div>
                      <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                        <p className="text-white font-medium mb-1">Do you offer rush delivery?</p>
                        <p className="text-neutral-400">Yes! Priority delivery in 40-58 hours with 20-30% surcharge.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form Alternative */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-light text-white mb-6 tracking-tight">
              Prefer a Quick Message?
            </h2>
            <p className="text-lg text-neutral-400 mb-8">
              Click the button below to start a WhatsApp conversation with pre-filled message template.
            </p>

            <div className="p-8 rounded-3xl bg-gradient-to-br from-green-500/10 to-emerald-500/10 backdrop-blur-xl border border-green-500/30">
              <div className="mb-6">
                <h3 className="text-xl font-semibold text-white mb-2">WhatsApp Direct Chat</h3>
                <p className="text-neutral-300 text-sm">
                  Pre-filled message: "I am interested in [Service Name]. Here are my project details: ..."
                </p>
              </div>

              <button
                onClick={handleWhatsAppClick}
                className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl text-white font-medium shadow-2xl shadow-green-500/25 hover:shadow-green-500/40 transition-all duration-300 hover:scale-105"
              >
                Open WhatsApp Chat
              </button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="relative p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
              <h2 className="text-3xl md:text-4xl font-light text-white mb-4 tracking-tight">
                Ready to Start Your Project?
              </h2>
              <p className="text-lg text-neutral-400 mb-8">
                Join hundreds of satisfied clients worldwide. Professional designs delivered in 2-3 days.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={handleWhatsAppClick}
                  className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl text-white font-medium shadow-2xl shadow-green-500/25 hover:shadow-green-500/40 transition-all duration-300 hover:scale-105"
                >
                  Message Us on WhatsApp
                </button>
                
                <a
                  href="mailto:teaminspirostudio@gmail.com"
                  className="px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
                >
                  Send Email Instead
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

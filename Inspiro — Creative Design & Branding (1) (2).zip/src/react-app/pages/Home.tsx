import { Link } from 'react-router';
import { ArrowRight, Play, Check, Sparkles, Palette, Zap, Globe, Users, Star } from 'lucide-react';
import NeuralBackground from '@/react-app/components/NeuralBackground';

export default function HomePage() {
  return (
    <div className="relative overflow-hidden">
      {/* Neural Network Background */}
      <NeuralBackground />

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="pt-32 pb-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Status Badge */}
            <div className="flex justify-center mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 backdrop-blur-xl border border-white/10">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-sm text-neutral-200">Crafting Distinctive Digital Identities</span>
              </div>
            </div>

            {/* Main Heading */}
            <div className="text-center max-w-5xl mx-auto mb-8">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-light text-white mb-6 tracking-tight leading-[0.95]">
                Creative Design that{' '}
                <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-teal-400 bg-clip-text text-transparent">
                  Truly Converts
                </span>
              </h1>
              <p className="text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto">
                Elevate your brand with professional graphics, branding, and digital content creation. 
                We design for clarity, impact, and measurable results worldwide.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <Link 
                to="/services" 
                className="group relative inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
              >
                <span>View Pricing</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
              
              <Link 
                to="/contact" 
                className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
              >
                <Play className="w-4 h-4" />
                <span>Book Service</span>
              </Link>
            </div>

            {/* Key Services Preview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {[
                { icon: Palette, title: 'Logo Design', desc: 'From $15' },
                { icon: Sparkles, title: 'Brand Kits', desc: 'From $48' },
                { icon: Zap, title: 'Social Media', desc: 'From $3' },
                { icon: Globe, title: 'Web Graphics', desc: 'From $10' },
              ].map((service, idx) => (
                <div 
                  key={idx}
                  className="group p-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 hover:scale-105"
                >
                  <service.icon className="w-6 h-6 text-purple-400 mb-3 group-hover:scale-110 transition-transform duration-200" />
                  <h3 className="text-white font-medium text-sm mb-1">{service.title}</h3>
                  <p className="text-neutral-400 text-xs">{service.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Preview */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 mb-6">
              <Users className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-neutral-200">Meet the Team</span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white mb-6 tracking-tight">
              Creative Minds Behind{' '}
              <span className="bg-gradient-to-r from-purple-400 to-teal-400 bg-clip-text text-transparent">
                Inspiro
              </span>
            </h2>
            
            <p className="text-neutral-400 text-lg mb-8 max-w-3xl mx-auto">
              Founded by <strong className="text-white">Sammrit Ghosh</strong> and <strong className="text-white">Aditya Ghosh</strong>, 
              Inspiro brings together creativity, professionalism, and global reach to deliver 
              exceptional design solutions for businesses worldwide.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto mb-8">
              {[
                'Professional design expertise',
                'Fast turnaround times (2-3 days)',
                'Global client satisfaction',
                '20% launch discount applied'
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3 justify-center md:justify-start">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-r from-purple-500 to-teal-500 flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-neutral-300">{feature}</span>
                </div>
              ))}
            </div>

            <Link 
              to="/about" 
              className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 font-medium transition-colors duration-200"
            >
              Learn more about us
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>

        {/* Quick Services */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 backdrop-blur-xl border border-white/10 mb-6">
              <Star className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-neutral-200">Popular Services</span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-light text-white mb-6 tracking-tight">
              Quick Service Overview
            </h2>
            
            <p className="text-neutral-400 text-lg mb-12 max-w-3xl mx-auto">
              Professional design services with transparent pricing. All prices include 20% launch discount.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: 'Logo Design',
                  price: '$15 - $67',
                  features: ['Multiple concepts', '2-3 revisions', 'Vector files included'],
                  popular: true
                },
                {
                  title: 'Brand Kit Starter',
                  price: '$48',
                  features: ['Basic logo design', 'Color palette', '2 social templates'],
                  popular: false
                },
                {
                  title: 'Social Media Posts',
                  price: '$3 - $8',
                  features: ['Custom designs', 'Platform optimized', 'Quick turnaround'],
                  popular: true
                }
              ].map((service, idx) => (
                <div 
                  key={idx} 
                  className={`relative p-6 rounded-2xl backdrop-blur-xl border transition-all duration-300 hover:scale-105 ${
                    service.popular 
                      ? 'bg-gradient-to-br from-purple-500/10 to-teal-500/10 border-purple-500/30' 
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  {service.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-purple-500 to-teal-500 text-white rounded-full">
                        Popular
                      </span>
                    </div>
                  )}
                  
                  <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                  <div className="text-2xl font-bold text-purple-400 mb-4">{service.price}</div>
                  
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2 text-sm text-neutral-300">
                        <Check className="w-4 h-4 text-emerald-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    to="/order" 
                    className="block w-full py-2.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/30 text-center text-white font-medium transition-all duration-200"
                  >
                    Order Now
                  </Link>
                </div>
              ))}
            </div>

            <div className="mt-12">
              <Link 
                to="/services" 
                className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
              >
                View All Services & Pricing
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 md:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="relative p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-teal-500/10 backdrop-blur-xl border border-white/10">
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-purple-500/5 via-blue-500/5 to-teal-500/5" />
              
              <h2 className="relative text-3xl md:text-4xl font-light text-white mb-4 tracking-tight">
                Ready to Transform Your Brand?
              </h2>
              <p className="relative text-lg text-neutral-400 mb-8">
                Join hundreds of satisfied clients worldwide. Professional designs delivered in 2-3 days.
              </p>
              
              <div className="relative flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link 
                  to="/order" 
                  className="px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 rounded-xl text-white font-medium shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105"
                >
                  Start Your Project Today
                </Link>
                <Link 
                  to="/contact" 
                  className="px-8 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium transition-all duration-300"
                >
                  Contact Us First
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
